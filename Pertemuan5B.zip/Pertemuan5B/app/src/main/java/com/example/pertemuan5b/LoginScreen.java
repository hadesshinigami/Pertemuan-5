package com.example.pertemuan5b;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class LoginScreen extends AppCompatActivity {
    EditText nama,pwd;
    TextView info;
    Button masuk;
    int counter = 5;
    private CheckBox show;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);

        nama=findViewById(R.id.nama);
        pwd=findViewById(R.id.password);
        masuk=findViewById(R.id.masuk);
        info=findViewById(R.id.textInfo);
        show=findViewById(R.id.showPass);

        show.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(show.isChecked()){
                    pwd.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }else {
                    pwd.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });

        masuk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validasi(nama.getText().toString(),pwd.getText().toString());
            }
        });
    }
    private void validasi(String nama, String pwd){
        if((nama.equals("ADMIN"))&&(pwd.equals("1234"))){
            Intent intent=new Intent(LoginScreen.this, FirstScreen.class);
            startActivity(intent);
        }else{
            counter--;
            info.setText("Sisa percobaan : "+String.valueOf(counter));
            if(counter==0){
                masuk.setEnabled(false);
            }
        }
    }
}
